<?php

    include_once "proveedor.php";



    $dato = $_SERVER['REQUEST_METHOD'];
    if($dato=="POST")
    {
        if(!empty($_POST['caso']))
        {
            $id = $_POST['id'];
            $email = $_POST['email'];
            $foto = $_POST['foto'];
            $nombre = $_POST['nombre'];
            $caso = $_POST['caso'];
            if($caso == "cargarProveedor")
            {
                $proveedor = new Proveedor($id,$nombre,$email,$foto);
                $proveedor->cargarProveedor("proveedores.txt");
            }
        }

    }
    if($dato=="GET")
    {
        $caso = $_GET['caso'];
        if(!empty($_GET['caso']))
        {
            if($caso == "consultarProveedor")
            {
                $nombre = $_GET['nombre'];
                $proveedor = Proveedor::buscarProveedor("proveedores.txt",$nombre);
            }
            else if($caso == "proveedores")
            {
                $mostrarProveedores = Proveedor::mostrarProveedores("proveedores.txt");
            }
        }

    }



?>