<?php

class Proveedor
{
    public $id;
    public $nombre;
    public $email;
    public $foto;

    function __construct($id,$nombre,$email,$foto)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email  = $email;
        $this->foto = $foto;

    }

    public function MostrarProveedor()
    {
        $datosProveedor = "id Proveedor: " . $this->id . "</br>" . "Nombre: " . $this->nombre . "</br>" . "Email: " . $this->email . "</br>" . "Foto: " . $this->foto . "</br>";
        return $datosProveedor;
    }

    public function escribirProveedor()
    {
        $datosProveedor = $this->id.",".$this->nombre.",".$this->email.",".$this->foto;
        return $datosProveedor;
    }

    public function cargarProveedor($nombreArchivo)
    {
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"a");
            fwrite($arch,"\n".$this->escribirProveedor());
            fclose($arch);
        }
        else
        {
            $arch = fopen($nombreArchivo,"w");
            fwrite($arch,$this->escribirProveedor());
            fclose($arch);
        }
    }

    static function buscarProveedor($nombreArchivo,$datoProveedor)
    {
        $arrayProveedores = self::traerProveedores($nombreArchivo);
                    
        foreach($arrayProveedores as $auxProveedor)
        {
                
            if(strcasecmp($auxProveedor->nombre,$datoProveedor)==0)
            {
                return $auxProveedor;
            }
            else if($auxProveedor->id == $datoProveedor)
            {
                return $auxProveedor;
            }
        }
        return NULL;        
    }

    static function traerProveedores($nombreArchivo)
    {
        $arrayProveedores = array();
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"r");
            while(!feof($arch))
            {
                $stringProveedor = trim(fgets($arch));
                $arrayProveedor = explode(",",$stringProveedor);
                $nuevoProveedor = new Proveedor($arrayProveedor[0],$arrayProveedor[1],$arrayProveedor[2],$arrayProveedor[3]);
                array_push($arrayProveedores,$nuevoProveedor);
            }
            fclose($arch);
        }
        else
        {
            echo "No existe el archivo $nombreArchivo"; 
        }
        if(!empty($arrayProveedores))
            return $arrayProveedores;
    }

    /*static function validarIdProveedor($idProveedor,$nombreArchivo)
    {
        $arrayProveedores = self::traerProveedores($nombreArchivo);
        foreach($arrayProveedores as $auxProveedor)
        {
            if($auxProveedor->id == $idProveedor)
                return true;
        }
        return false;
    }*/

   /* function cargarProveedor($id,$nombre,$email,$foto,$nombreArchivo)
    {
        $proveedor = new Proveedor($nombre,$edad,$dni,$legajo);
        $proveedor->guardar_proveedor($nombreArchivo);        
        echo "Proveedor agregado exito";
    }*/

    
}

?>