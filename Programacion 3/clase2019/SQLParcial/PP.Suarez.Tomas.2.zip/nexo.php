<?php

    include_once "proveedor.php";
    include_once "pedido.php";

    $dato = $_SERVER['REQUEST_METHOD'];
    if($dato=="POST")
    {
        $caso = $_POST['caso'];
        if(!empty($_POST['caso']))
        {
            if($caso == "cargarProveedor")
            {
                $id = $_POST['id'];
                $email = $_POST['email'];
                $foto = $_POST['foto'];
                $nombre = $_POST['nombre'];
                $proveedor = new Proveedor($id,$nombre,$email,$foto);
                $proveedor->cargarProveedor("proveedores.txt");
            }
            else if($caso == "hacerPedido")
            {
                $producto = $_POST['producto'];
                $cantidad = $_POST['cantidad'];
                $idProveedor = $_POST['idProveedor'];
                if(Proveedor::buscarProveedor("proveedores.txt",$idProveedor)!=NULL)
                {
                    $nuevoPedido = new Pedido($producto,$cantidad,$idProveedor);
                    $nuevoPedido->hacerPedido("pedidos.txt");
                    echo "Pedido realizado con exito</br>";
                }
                else
                    echo "No se encontro proveedor, no se puede realizar pedido</br>";
            }
        }

    }
    if($dato=="GET")
    {
        $caso = $_GET['caso'];
        if(!empty($_GET['caso']))
        {
            if($caso == "consultarProveedor")
            {
                $nombre = $_GET['nombre'];
                $proveedor = Proveedor::buscarProveedor("proveedores.txt",$nombre);
                if($proveedor != NULL)
                {
                    echo $auxProveedor->MostrarProveedor();
                }
                else
                {
                    echo "No se encontro proveedor ".$nombre."</br>"; 
                }
            }
            else if($caso == "proveedores")
            {
                $mostrarProveedores = Proveedor::traerProveedores("proveedores.txt");
                
                foreach($mostrarProveedores as $auxProveedor)
                {
                     echo $auxProveedor->MostrarProveedor() . "</br>";
                }
            }
            else if($caso == "listarPedidos")
            {
                $arrayPedidos = Pedido::traerPedidos("pedidos.txt");
                $arrayProveedores = Proveedor::traerProveedores("proveedores.txt");
                if(!empty($arrayPedidos)&&!empty($arrayProveedores))
                {
                    echo "<b>Lista de pedidos:</b> </br></br>";
                    foreach($arrayPedidos as $auxPedido)
                    {
                        $auxProveedor = Proveedor::buscarProveedor("proveedores.txt",$auxPedido->idProveedor);
                        if($auxProveedor != NULL)
                        {
                            echo $auxPedido->MostrarPedido()."Nombre Proveedor: ".$auxProveedor->nombre."</br></br>";
                        }
                    }
                }
                else
                    echo "No se pueden mostrar los pedidos</br>";
            }
            /* 6- (1pts.) caso: listarPedidoProveedor(get): Ingreso el id del proveedor y me muestra los pedidos que tiene.  */
            else if($caso == "listarPedidosProveedor")
            {
                $idProveedor = $_GET['idProveedor'];
                $auxProveedor = Proveedor::buscarProveedor("proveedores.txt",$idProveedor);
                $arrayPedidos = Pedido::traerPedidos("pedidos.txt");
                $encontroPedido = false;
                if($auxProveedor!=NULL)
                {
                    foreach($arrayPedidos as $auxPedido)
                    {
                        if($auxPedido->idProveedor == $auxProveedor->id)
                        {
                            if(!$encontroPedido)
                            {
                                echo "<b>Pedidos del proveedor ID $auxProveedor->id ($auxProveedor->nombre): </b></br></br>";
                                $encontroPedido = true;
                            }
                            echo $auxPedido->MostrarPedido()."Nombre Proveedor: ".$auxProveedor->nombre."</br></br>";
                        }
                    }
                }
                else
                    echo "No existe proveedor ID <b>$idProveedor</br></b>";
            }
        }

    }



?>