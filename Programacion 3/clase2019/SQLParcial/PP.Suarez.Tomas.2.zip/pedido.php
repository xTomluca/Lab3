<?php
include_once "proveedor.php";

class Pedido
{
    public $producto;
    public $cantidad;
    public $idProveedor;
    
    function __construct($producto,$cantidad,$idProveedor)
    {
        $this->producto = $producto;
        $this->cantidad = $cantidad;
        $this->idProveedor = $idProveedor;
    }
    
    public function escribirPedido()
    {
        $datosPedido = $this->producto.",".$this->cantidad.",".$this->idProveedor;
        return $datosPedido;
    }

    public function mostrarPedido()
    {
        $datosPedido = "Producto: " . $this->producto . "</br>" . "Cantidad: " . $this->cantidad . "</br>" . "Id Proveedor: " . $this->idProveedor . "</br>";
        return $datosPedido;
    }
    
    public function hacerPedido($nombreArchivo)
    {
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"a");
            fwrite($arch,"\n".$this->escribirPedido());
            fclose($arch);
        }
        else
        {
            $arch = fopen($nombreArchivo,"w");
            fwrite($arch,$this->escribirPedido());
            fclose($arch);
        }
    }
    
    static function traerPedidos($nombreArchivo)
    {
        $arrayPedidos = array();
        if(file_exists($nombreArchivo))
        {
            $arch = fopen($nombreArchivo,"r");
            while(!feof($arch))
            {
                $stringPedido = trim(fgets($arch));
                $arrayPedido = explode(",",$stringPedido);
                $nuevoPedido = new Pedido($arrayPedido[0],$arrayPedido[1],$arrayPedido[2]);
                array_push($arrayPedidos,$nuevoPedido);
            }
            fclose($arch);
        }
        else
        {
            echo "No existe el archivo proveedores.txt"; 
        }
        if(!empty($arrayPedidos))
            return $arrayPedidos;
    }


}



?>